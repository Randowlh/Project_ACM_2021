//定义Student class，包含ID（学号），name(姓名)， class（班级），电话（phone number），电子邮箱（email） 等数据段；
public class Student {
    public String ID,name,_class,phone,email;
    public Student(String ID,String name,String _class,String phone,String email){
        this.ID = ID;
        this.name = name;
        this._class = _class;
        this.phone = phone;
        this.email = email;
    }
}
