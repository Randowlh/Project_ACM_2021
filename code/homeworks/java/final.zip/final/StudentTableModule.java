

import java.util.*;
import javax.swing.table.AbstractTableModel;

public class StudentTableModule extends AbstractTableModel {

    String[] columnNames = {"学号","姓名","班级","电话","电子邮件"};
    String[][] Data;
    public StudentTableModule(Vector<Student> students){
        Data = new String[students.size()][5];
        for(int i = 0;i < students.size();i++){
            Data[i][0] = students.get(i).ID;
            Data[i][1] = students.get(i).name;
            Data[i][2] = students.get(i)._class;
            Data[i][3] = students.get(i).phone;
            Data[i][4]= students.get(i).email;
        }
    }
    // 返回一共有多少行
    public int getRowCount() {
// TODO Auto-generated method stub
        return Data.length;
    }

    // 返回一共有多少列
    public int getColumnCount() {
// TODO Auto-generated method stub
        return columnNames.length;
    }

    // 获取每一列的名称
    public String getColumnName(int columnIndex) {
// TODO Auto-generated method stub
        return columnNames[columnIndex];
    }

    // 单元格是否可以修改
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }

    // 每一个单元格里的值
    public Object getValueAt(int rowIndex, int columnIndex) {
// TODO Auto-generated method stub
        return Data[rowIndex][columnIndex];
    }

}