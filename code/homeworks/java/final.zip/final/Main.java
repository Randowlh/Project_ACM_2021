//using Java Swing to create a calculator by zwj 19041805
//结合Swing中的Table组件，创建一个班级通讯录，其UI主界面类似下图，并带有几个功能按钮。
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
public class Main{
    JFrame frame;
    JPanel panel;
    JTextField textField;
    JButton  btn_import,btn_output,add,delete;
    //通讯录表格
    JTable table;
    Font font = new Font("Arial", Font.BOLD, 20);
    //学生信息Vector
    Vector<Student> students = new Vector<>();
    public static void main(String[] args){
        java.awt.EventQueue.invokeLater(Main::new);
    }
    public Main(){
        frame = new JFrame("通讯录");
        frame.setVisible(true);
        frame.setSize(700, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        panel = new JPanel();
        GridBagLayout layout = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        panel.setLayout(layout);
        //设定全局字体

        //从文件导入通讯录
        btn_import = new JButton("从文件导入");
        btn_import.setFont(font);
        btn_import.addActionListener(e -> {
            //跳出对话框，获取文件路径
            JFileChooser jfc = new JFileChooser();
            jfc.showOpenDialog(null);
            String filePath = jfc.getSelectedFile().getAbsolutePath();
            //读取文件
            String[] lines = new String[0];
            try{
                lines = new java.io.BufferedReader(new java.io.FileReader(filePath)).lines().toArray(String[]::new);
            }catch(Exception e1){
                e1.printStackTrace();
            }
            //导入新数据
            for(String line : lines){
                String[] data = line.split(" ");
                students.add(new Student(data[0],data[1],data[2],data[3],data[4]));
            }
            //刷新表格
            table.setModel(new StudentTableModule(students));
        });
        btn_output = new JButton("导出到文件");
        btn_output.setFont(font);
        btn_output.addActionListener(e -> {
            //跳出对话框，获取文件路径
            JFileChooser jfc = new JFileChooser();
            jfc.showSaveDialog(null);
            String filePath = jfc.getSelectedFile().getAbsolutePath();
            //写入文件
            try{
                java.io.PrintWriter pw = new java.io.PrintWriter(filePath);
                for(Student student : students){
                    pw.print(student.ID);
                    pw.print(' ');
                    pw.print(student.name);
                    pw.print(' ');
                    pw.print(student._class);
                    pw.print(' ');
                    pw.print(student.phone);
                    pw.print(' ');
                    pw.println(student.email);
                }
                pw.close();
            }catch(Exception e1){
                e1.printStackTrace();
            }
        });
        //添加学生
        add = new JButton("添加学生");
        add.setFont(font);
        add.addActionListener(e -> {
            //跳出对话框，获取文件路径
            JTextField ID = new JTextField();
            JTextField name = new JTextField();
            JTextField _class = new JTextField();
            JTextField phone = new JTextField();
            JTextField email = new JTextField();
            JPanel panel = new JPanel();
            GridBagLayout layout2 = new GridBagLayout();
            GridBagConstraints gbc2 = new GridBagConstraints();
            gbc2.gridx = 0;
            gbc2.gridy = 0;
            gbc2.gridwidth = 1;
            gbc2.gridheight = 1;
            gbc2.weightx = 1;
            gbc2.weighty = 1;
            gbc2.fill = GridBagConstraints.BOTH;
            panel.setLayout(layout2);
            panel.add(new JLabel("学号"),gbc2);
            gbc2.gridx = 1;
            gbc2.gridwidth = 3;
            panel.add(ID,gbc2);
            gbc2.gridx = 0;
            gbc2.gridy = 1;
            gbc2.gridwidth = 1;
            panel.add(new JLabel("姓名"),gbc2);
            gbc2.gridx = 1;
            gbc2.gridwidth = 3;
            panel.add(name,gbc2);
            gbc2.gridx = 0;
            gbc2.gridy = 2;
            gbc2.gridwidth = 1;
            panel.add(new JLabel("班级"),gbc2);
            gbc2.gridx = 1;
            gbc2.gridwidth = 3;
            panel.add(_class,gbc2);
            gbc2.gridx = 0;
            gbc2.gridy = 3;
            gbc2.gridwidth = 1;
            panel.add(new JLabel("手机"),gbc2);
            gbc2.gridx = 1;
            gbc2.gridwidth = 3;
            panel.add(phone,gbc2);
            gbc2.gridx = 0;
            gbc2.gridy = 4;
            gbc2.gridwidth = 1;
            panel.add(new JLabel("电子邮件"),gbc2);
            gbc2.gridx = 1;
            gbc2.gridwidth = 3;
            panel.add(email,gbc2);
            //no logos
            JOptionPane.showMessageDialog(null,panel,"添加学生",JOptionPane.PLAIN_MESSAGE);
            //添加学生
            students.add(new Student(ID.getText(),name.getText(),_class.getText(),phone.getText(),email.getText()));
            table.setModel(new StudentTableModule(students));

        });
        delete = new JButton("删除学生");
        delete.setFont(font);
        delete.addActionListener(e -> {
            //跳出对话框，获取文件路径
            JTextField ID = new JTextField();
            JPanel panel = new JPanel();
            GridBagLayout layout3 = new GridBagLayout();
            GridBagConstraints gbc3 = new GridBagConstraints();
            gbc3.gridx = 0;
            gbc3.gridy = 0;
            gbc3.gridwidth = 3;
            gbc3.gridheight = 1;
            gbc3.weightx = 1;
            gbc3.weighty = 1;
            gbc3.fill = GridBagConstraints.BOTH;
            panel.setLayout(layout3);
            //设定字体
            JLabel tt=new JLabel("学号:");
            tt.setFont(font);
            panel.add(tt,gbc3);
            gbc3.gridy = 1;
            panel.add(ID,gbc3);
            JOptionPane.showMessageDialog(null, panel, "删除学生", JOptionPane.PLAIN_MESSAGE);
            //删除学生
            for(int i = 0; i < students.size(); i++){
                if(students.get(i).ID.equals(ID.getText())){
                    students.remove(i);
                    break;
                }
            }
            //刷新表格
            table.setModel(new StudentTableModule(students));
        });
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        panel.add(btn_import, gbc);
        //导出通讯录
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        panel.add(btn_output, gbc);
        //添加联系人
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        panel.add(add, gbc);
        //删除联系人
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        gbc.gridheight = 1;
        panel.add(delete, gbc);
        //通讯录表格
        table = new JTable(new StudentTableModule(students));
        table.setFont(font);
        JScrollPane scrollPane = new JScrollPane(table);
        //列表框自适应大小
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 4;
        gbc.gridheight = 1;
        panel.add(scrollPane, gbc);
        frame.add(panel);

    }
}